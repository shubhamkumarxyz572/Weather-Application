# <img src="https://raw.githubusercontent.com/ksalokya/weather_v2/main/public/images/favicon.ico"></img>Weather App 
### Used Openweathermap API with dynamic updates, 5 day forecast and city search option.
### Website - [Click Here](https://beat-the-weather-v2.herokuapp.com)

#### This is an improved version of my previous work. [Repository](https://github.com/ksalokya/weather)
